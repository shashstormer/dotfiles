#!/bin/bash
if pgrep -x "wf-recorder" > /dev/null; then
    pkill -INT wf-recorder
    notify-send "Recording Stopped" "File saved in ~/"
else
    notify-send "Recording Started" "Recording selection..."
    # Record screen with audio (if you want audio, add --audio)
    wf-recorder -g "$(slurp)" -f ~/Videos/recording_$(date +"%Y-%m-%d_%H-%M-%S").mp4
fi
